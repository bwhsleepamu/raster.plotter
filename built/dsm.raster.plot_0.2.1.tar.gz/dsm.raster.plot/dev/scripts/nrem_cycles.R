# characterize stages ==> nrem, rem, wake, undef
# merge undef --> closest neighbor (here or later?)
# use change point analysis to find change points
# get prevalent state between changepoints --> label
# merge --> 5 min rem, 15 nrem, 5 min wake (except first rem)
# party!
# graph
# copute stats
# compute 