## 0.2.0
### Enhancements
- Added support for 4 different types of events.
- Added gap between days
- Added image height scaling depending on number of days displayed
- Changed formatting for day labels

### Documentation
- Added example raster image

### Bug Fix
- Fixed lack of support for events spanning more than one day

## 0.1.1
### Bug Fix
- Fixed Issue #1
